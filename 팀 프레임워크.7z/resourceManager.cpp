#include "stdafx.h"
#include "resourceManager.h"
