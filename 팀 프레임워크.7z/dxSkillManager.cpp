#include "stdafx.h"
#include "dxSkillManager.h"

