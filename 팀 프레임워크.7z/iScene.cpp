#include "stdafx.h"
#include "iScene.h"


iScene::iScene()
{
}


iScene::~iScene()
{
}
