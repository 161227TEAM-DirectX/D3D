#include "stdafx.h"
#include "xPlayerStatus.h"
