#include "stdafx.h"
#include "bossActionSkill.h"


bossActionSkill::bossActionSkill()
	:Action()
{
}


bossActionSkill::~bossActionSkill()
{
}

int bossActionSkill::Start()
{
	return 0;
}

int bossActionSkill::Update()
{
	return 0;
}
