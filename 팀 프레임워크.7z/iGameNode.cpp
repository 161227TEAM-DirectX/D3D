#include "stdafx.h"
#include "iGameNode.h"


iGameNode::iGameNode()
{
}


iGameNode::~iGameNode()
{
}
