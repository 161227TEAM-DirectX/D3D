//#pragma once
//#include "bossActionAttack.h"
//#include "bossActionCinema.h"
//#include "bossActionDie.h"
//#include "bossActionFly.h"
//#include "bossActionFlyDie.h"
//#include "bossActionFlyMove.h"
//#include "bossActionLanding.h"
//#include "bossActionMove.h"
//#include "bossActionSkillBattleRoar.h"
//#include "bossActionSkillFire.h"
//#include "bossActionSkillFlyFire.h"
//#include "bossActionSkillFlyStandingFire.h"
//#include "bossActionSkillTailAtt.h"
//#include "bossActionStanding.h"
//#include "bossActionSkill.h"
//
//
//
//class bossMonster;
//class bossActionControl
//{
//private:
//	bossMonster* linkBoss;
//public:
//	bossActionControl(bossMonster* temp);
//	~bossActionControl();
//
//	void switchState(LHS::ACTIONRESULT& result);
//	void Init(Action*& CurrAction, LHS::ACTIONRESULT& result);
//};
//
