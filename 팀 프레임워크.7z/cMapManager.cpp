#include "stdafx.h"
#include "cMapManager.h"


cMapManager::cMapManager()
{
}


cMapManager::~cMapManager()
{
}
