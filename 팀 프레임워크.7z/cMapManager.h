#pragma once

#define MAP_MANAGER cMapManager::GetInstance()

class cMapManager
{
	SINGLETONE(cMapManager);

public:

};

